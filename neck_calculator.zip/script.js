// Script para la calculadora de circunferencia del cuello
document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const ageInput = document.getElementById('age');
    const neckCircumferenceInput = document.getElementById('neck-circumference');
    const calculateBtn = document.getElementById('calculate-btn');
    
    // Elementos de resultado
    const expectedValue = document.getElementById('expected-value');
    const expectedMin = document.getElementById('expected-min');
    const expectedMax = document.getElementById('expected-max');
    const sdValue = document.getElementById('sd-value');
    const percentileValue = document.getElementById('percentile-value');
    const interpretationText = document.getElementById('interpretation-text');
    
    // Evento de clic en el botón calcular
    calculateBtn.addEventListener('click', calculateResults);
    
    // También calcular al presionar Enter en los campos de entrada
    ageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateResults();
    });
    
    neckCircumferenceInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateResults();
    });
    
    // Función principal de cálculo
    function calculateResults() {
        // Obtener valores de entrada
        const age = parseFloat(ageInput.value);
        const neckCircumference = parseFloat(neckCircumferenceInput.value);
        
        // Validar entradas
        if (isNaN(age) || age < 0) {
            showError('Por favor, ingrese una edad válida entre 0 y 12 años.');
            return;
        }
        
        if (isNaN(neckCircumference) || neckCircumference < 16 || neckCircumference > 34) {
            showError('Por favor, ingrese una circunferencia válida entre 16 y 34 cm.');
            return;
        }
        
        // Obtener datos interpolados para la edad
        const data = interpolateValue(age, neckCircumferenceData);
        
        if (!data) {
            showError('No se pudieron calcular los resultados para la edad proporcionada.');
            return;
        }
        
        // Calcular la desviación estándar
        const sd = calculateSD(age, neckCircumference);
        
        // Actualizar la interfaz con los resultados
        expectedValue.textContent = data[1].toFixed(1) + ' cm';
        expectedMin.textContent = data[2].toFixed(1);
        expectedMax.textContent = data[3].toFixed(1);
        
        // Mostrar SD con signo y 2 decimales
        const sdFormatted = sd > 0 ? '+' + sd.toFixed(2) : sd.toFixed(2);
        sdValue.textContent = sdFormatted + ' SD';
        
        // Calcular y mostrar el percentil
        const percentile = calculatePercentile(sd);
        percentileValue.textContent = percentile;
        
        // Generar interpretación
        interpretationText.textContent = generateInterpretation(age, neckCircumference, sd, data);
        
        // Aplicar clases de estilo según el resultado
        applyResultStyles(sd);
    }
    
    // Función para mostrar errores
    function showError(message) {
        interpretationText.textContent = message;
        interpretationText.style.color = 'var(--color-error)';
        
        // Restablecer los valores de resultado
        expectedValue.textContent = '--';
        expectedMin.textContent = '--';
        expectedMax.textContent = '--';
        sdValue.textContent = '--';
        percentileValue.textContent = '--';
    }
    
    // Función para generar la interpretación
    function generateInterpretation(age, measurement, sd, data) {
        let interpretation = '';
        
        // Interpretación basada en la desviación estándar
        if (sd < -2) {
            interpretation = `La circunferencia del cuello de ${measurement.toFixed(1)} cm está por debajo del rango normal para la edad de ${age.toFixed(1)} años (más de 2 desviaciones estándar por debajo de la media). Esto podría indicar un desarrollo por debajo de lo esperado.`;
        } else if (sd > 2) {
            interpretation = `La circunferencia del cuello de ${measurement.toFixed(1)} cm está por encima del rango normal para la edad de ${age.toFixed(1)} años (más de 2 desviaciones estándar por encima de la media). Esto podría indicar un desarrollo por encima de lo esperado.`;
        } else if (sd >= -2 && sd <= 2) {
            interpretation = `La circunferencia del cuello de ${measurement.toFixed(1)} cm está dentro del rango normal para la edad de ${age.toFixed(1)} años (entre -2 y +2 desviaciones estándar de la media).`;
            
            // Añadir más detalle según la posición dentro del rango normal
            if (sd > 0.5) {
                interpretation += ' El valor está en la parte superior del rango normal.';
            } else if (sd < -0.5) {
                interpretation += ' El valor está en la parte inferior del rango normal.';
            } else {
                interpretation += ' El valor está muy cerca de la media esperada.';
            }
        }
        
        // Añadir información sobre la edad
        if (age > 12) {
            interpretation += ' Nota: Para edades superiores a 12 años, se utilizan los valores de referencia de 12 años.';
        }
        
        return interpretation;
    }
    
    // Función para aplicar estilos según el resultado
    function applyResultStyles(sd) {
        // Restablecer estilos
        sdValue.style.color = 'var(--color-primary)';
        
        // Aplicar color según la desviación estándar
        if (sd < -2) {
            sdValue.style.color = 'var(--color-error)';
        } else if (sd > 2) {
            sdValue.style.color = '#2e7d32'; // Verde para valores altos
        }
    }
});
