// Datos extraídos de la gráfica de circunferencia del cuello por edad
// Valores aproximados basados en la gráfica proporcionada
// Estructura: [edad, media, -2SD, +2SD]

const neckCircumferenceData = [
    // Edad 0 (nacimiento)
    [0, 19, 16.5, 21.5],
    // Edad 1
    [1, 22, 19, 24.5],
    // Edad 2
    [2, 23, 20, 26],
    // Edad 3
    [3, 24, 21, 27],
    // Edad 4
    [4, 24.5, 21.5, 27.5],
    // Edad 5
    [5, 25, 22, 28],
    // Edad 6
    [6, 25.5, 22.5, 28.5],
    // Edad 7
    [7, 26, 23, 29],
    // Edad 8
    [8, 26.5, 23.5, 29.5],
    // Edad 9
    [9, 27, 24, 30],
    // Edad 10
    [10, 27.5, 24.5, 30.5],
    // Edad 11
    [11, 28, 25, 31],
    // Edad 12
    [12, 28.5, 25.5, 31.5]
];

// Función para interpolar valores entre edades
function interpolateValue(age, dataArray) {
    // Si la edad es mayor a 12, usar los valores de 12 años
    if (age >= 12) {
        return dataArray[12];
    }
    
    // Si la edad es exactamente uno de los valores en la tabla
    for (let i = 0; i < dataArray.length; i++) {
        if (dataArray[i][0] === age) {
            return dataArray[i];
        }
    }
    
    // Interpolar entre dos edades
    let lowerIndex = Math.floor(age);
    let upperIndex = Math.ceil(age);
    
    // Si son iguales (edad es un número entero pero no está en la tabla)
    if (lowerIndex === upperIndex) {
        return null; // No debería ocurrir con nuestros datos
    }
    
    // Encontrar los datos para las edades inferior y superior
    let lowerData = null;
    let upperData = null;
    
    for (let i = 0; i < dataArray.length; i++) {
        if (dataArray[i][0] === lowerIndex) {
            lowerData = dataArray[i];
        }
        if (dataArray[i][0] === upperIndex) {
            upperData = dataArray[i];
        }
    }
    
    if (!lowerData || !upperData) {
        return null; // No debería ocurrir con nuestros datos
    }
    
    // Calcular la fracción entre las dos edades
    let fraction = age - lowerIndex;
    
    // Interpolar cada valor (media, -2SD, +2SD)
    let interpolatedData = [
        age,
        lowerData[1] + fraction * (upperData[1] - lowerData[1]),
        lowerData[2] + fraction * (upperData[2] - lowerData[2]),
        lowerData[3] + fraction * (upperData[3] - lowerData[3])
    ];
    
    return interpolatedData;
}

// Función para calcular el percentil basado en la desviación estándar
function calculatePercentile(sd) {
    // Valores aproximados de percentiles basados en desviaciones estándar
    if (sd <= -2) return "< 2.3%";
    if (sd <= -1.5) return "2.3% - 6.7%";
    if (sd <= -1) return "6.7% - 16%";
    if (sd <= -0.5) return "16% - 30%";
    if (sd <= 0.5) return "30% - 70%";
    if (sd <= 1) return "70% - 84%";
    if (sd <= 1.5) return "84% - 93.3%";
    if (sd <= 2) return "93.3% - 97.7%";
    return "> 97.7%";
}

// Función para calcular la desviación estándar basada en la medición
function calculateSD(age, measurement) {
    const data = interpolateValue(age, neckCircumferenceData);
    if (!data) return null;
    
    const mean = data[1];
    const minus2SD = data[2];
    const plus2SD = data[3];
    
    // Calcular el valor de 1 SD (asumiendo distribución normal)
    const oneSD = (plus2SD - minus2SD) / 4;
    
    // Calcular cuántas SD está el valor medido de la media
    return (measurement - mean) / oneSD;
}
